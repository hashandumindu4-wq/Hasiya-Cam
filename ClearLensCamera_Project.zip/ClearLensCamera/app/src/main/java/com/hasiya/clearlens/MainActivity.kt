package com.hasiya.clearlens

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private var imageCapture: ImageCapture? = null
    private var frontCamera = false
    private var zoom = 1f
    private var chosenFilter = "Natural"
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var zoomText: TextView

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else Toast.makeText(this, "Camera permission is needed to use ClearLens.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 10, 18)
        window.navigationBarColor = android.graphics.Color.rgb(8, 10, 18)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(android.graphics.Color.rgb(8,10,18)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(18, 12, 18, 12) }
        val brand = TextView(this).apply { text = "ClearLens"; textSize = 24f; setTextColor(-1); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        val subtitle = TextView(this).apply { text = "  •  OFFLINE CAMERA"; textSize = 10f; setTextColor(android.graphics.Color.rgb(167,139,250)) }
        header.addView(brand); header.addView(subtitle); root.addView(header)
        previewView = PreviewView(this).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE; scaleType = PreviewView.ScaleType.FILL_CENTER }
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 16) }
        zoomText = TextView(this).apply { text = "ZOOM  1.0×"; textSize = 12f; setTextColor(-1); gravity = Gravity.CENTER_HORIZONTAL }
        controls.addView(zoomText)
        val zoomBar = SeekBar(this).apply { max = 40; progress = 0; setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { zoom = 1f + p / 10f; zoomText.text = "ZOOM  %.1f×".format(Locale.US, zoom); previewView.tag = zoom }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { applyZoom() }
        }) }
        controls.addView(zoomBar)
        val filterTitle = TextView(this).apply { text = "LOOKS"; textSize = 11f; setTextColor(android.graphics.Color.LTGRAY); setPadding(2, 8, 0, 6) }; controls.addView(filterTitle)
        val filters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; }
        listOf("Natural", "Vivid", "Warm", "Mono", "Cool").forEach { f ->
            val b = TextView(this).apply { text = f; textSize = 12f; gravity = Gravity.CENTER; setTextColor(if (f == chosenFilter) android.graphics.Color.BLACK else -1); setPadding(10, 10, 10, 10); setBackgroundColor(if (f == chosenFilter) android.graphics.Color.rgb(167,139,250) else android.graphics.Color.rgb(35,38,52)); setOnClickListener { chosenFilter = f; for (i in 0 until filters.childCount) { val v = filters.getChildAt(i) as TextView; v.setTextColor(if (v.text == chosenFilter) android.graphics.Color.BLACK else -1); v.setBackgroundColor(if (v.text == chosenFilter) android.graphics.Color.rgb(167,139,250) else android.graphics.Color.rgb(35,38,52)) }; Toast.makeText(this@MainActivity, "$f look will be applied to the saved photo", Toast.LENGTH_SHORT).show() } }
            val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.setMargins(3, 0, 3, 0); filters.addView(b, lp)
        }
        controls.addView(filters)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 14, 0, 2) }
        val flip = makeButton("FLIP") { frontCamera = !frontCamera; startCamera() }
        val capture = TextView(this).apply { text = "●"; textSize = 36f; gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE); setBackgroundColor(android.graphics.Color.rgb(124,92,230)); setOnClickListener { takePhoto() } }
        val cp = LinearLayout.LayoutParams(76, 64); cp.setMargins(22, 0, 22, 0)
        val hint = makeButton("GALLERY") { openGallery() }
        bottom.addView(flip); bottom.addView(capture, cp); bottom.addView(hint); controls.addView(bottom)
        root.addView(controls)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) = TextView(this).apply { text = label; textSize = 11f; gravity = Gravity.CENTER; setTextColor(-1); setPadding(12, 16, 12, 16); setBackgroundColor(android.graphics.Color.rgb(35,38,52)); setOnClickListener { action() } }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
                val selector = if (frontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                provider.unbindAll()
                val camera = provider.bindToLifecycle(this, selector, preview, imageCapture)
                camera.cameraControl.setZoomRatio(zoom.coerceAtLeast(1f))
            } catch (e: Exception) { Toast.makeText(this, "Camera could not start on this device.", Toast.LENGTH_LONG).show() }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun applyZoom() { startCamera() }

    private fun takePhoto() {
        val capture = imageCapture ?: run { Toast.makeText(this, "Camera is starting. Try again in a moment.", Toast.LENGTH_SHORT).show(); return }
        val name = "ClearLens_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val values = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg"); if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearLens") }
        val output = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        capture.takePicture(output, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onError(exception: ImageCaptureException) { runOnUiThread { Toast.makeText(this@MainActivity, "Photo failed: ${exception.message}", Toast.LENGTH_LONG).show() } }
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                val uri = result.savedUri
                if (uri != null && chosenFilter != "Natural") applyFilterToSavedPhoto(uri, chosenFilter)
                runOnUiThread { Toast.makeText(this@MainActivity, "Photo saved in Pictures/ClearLens", Toast.LENGTH_LONG).show() }
            }
        })
    }

    private fun applyFilterToSavedPhoto(uri: Uri, filter: String) {
        try {
            val original = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
            val output = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(output)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val matrix = when (filter) {
                "Vivid" -> ColorMatrix().apply { setSaturation(1.35f) }
                "Warm" -> ColorMatrix(floatArrayOf(1.08f,0f,0f,0f,8f, 0f,1.02f,0f,0f,2f, 0f,0f,0.90f,0f,0f, 0f,0f,0f,1f,0f))
                "Mono" -> ColorMatrix().apply { setSaturation(0f) }
                "Cool" -> ColorMatrix(floatArrayOf(0.94f,0f,0f,0f,0f, 0f,1.01f,0f,0f,0f, 0f,0f,1.10f,0f,5f, 0f,0f,0f,1f,0f))
                else -> ColorMatrix()
            }
            paint.colorFilter = ColorMatrixColorFilter(matrix)
            canvas.drawBitmap(original, 0f, 0f, paint)
            contentResolver.openOutputStream(uri, "w")?.use { stream -> output.compress(Bitmap.CompressFormat.JPEG, 95, stream) }
            original.recycle(); output.recycle()
        } catch (_: Exception) { runOnUiThread { Toast.makeText(this, "Photo saved, but the filter could not be applied.", Toast.LENGTH_LONG).show() } }
    }

    private fun openGallery() { try { val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply { setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*"); addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK) }; startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "No gallery app found.", Toast.LENGTH_SHORT).show() } }
    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }
}
